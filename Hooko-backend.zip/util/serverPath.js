exports.serverPath = "YOUR_SERVER_PATH"; // example: https://example.example.com/

exports.serverKey = "SERVER_KEY"; //get this from firebase
