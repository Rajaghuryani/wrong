module.exports = {
  //port
  PORT: process.env.PORT || 5000,

  //secret key
  secret_key: "THIS_IS_YOUR_SECRET_KEY",
};
